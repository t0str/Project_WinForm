﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        List<TabPage> tabPage = new List<TabPage>();
        List<RichTextBox> richTextBoxes = new List<RichTextBox>();
        List<Button> buttons = new List<Button>();
        int changes = 0;

        /// <summary>
        /// Выставление настроек.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            toolStripComboBox1.SelectedIndex = 0;
            try
            {
                string[] settings = File.ReadAllLines("settings.txt");
                switch (settings[0])
                {
                    case "White":
                        BackColor = Color.White;
                        break;
                    case "Blue":
                        BackColor = Color.Blue;
                        break;
                    case "Gray":
                        BackColor = Color.Gray;
                        break;
                    default:
                        BackColor = Color.Blue;
                        break;
                }
                toolStripComboBox1.SelectedIndex = int.Parse(settings[1]);
                for (int i = 2; i < settings.Length; i++)
                {
                    NewButtons();
                    tabPage[^1].Controls.Add(buttons[^1]);
                    tabPage[^1].Location = new Point(4, 29);
                    tabPage[^1].Name = $"tabPage{tabPage.Count}";
                    Padding = new Padding(3);
                    tabPage[^1].Size = new Size(1243, 442);
                    tabPage[^1].TabIndex = 0;
                    tabPage[^1].Text = $"tabPage{tabPage.Count}";
                    tabPage[^1].UseVisualStyleBackColor = true;
                    tabControl1.Controls.Add(tabPage[^1]);
                    try
                    {
                        richTextBoxes[^1].Rtf = File.ReadAllText(settings[i]);
                        tabPage[^1].Text = settings[i];
                    }
                    catch
                    {
                        try
                        {
                            richTextBoxes[^1].Text = File.ReadAllText(settings[i]);
                            tabPage[^1].Text = settings[i];
                        }
                        catch (Exception ex)
                        {
                            label1.Text = ex.Message;
                        }
                    }
                }
                File.Delete("settings.txt");
            }
            catch
            {
            }
        }

        /// <summary>
        /// Создание новых текст боксов и кнопок Сохранить.
        /// </summary>
        private void NewButtons()
        {
            tabPage.Add(new TabPage());
            richTextBoxes.Add(new RichTextBox());
            buttons.Add(new Button());
            richTextBoxes[^1].Location = new Point(6, 3);
            richTextBoxes[^1].Name = $"richTextBox{richTextBoxes.Count}";
            richTextBoxes[^1].Size = new Size(1231, 329);
            richTextBoxes[^1].TabIndex = 7;
            richTextBoxes[^1].Text = "";
            richTextBoxes[^1].ContextMenuStrip = contextMenuStrip1;
            richTextBoxes[^1].TextChanged += text_KeyDown;
            tabPage[^1].Controls.Add(richTextBoxes[^1]);
            buttons[^1].Location = new Point(0, 351);
            buttons[^1].Name = $"button{buttons.Count}";
            buttons[^1].Size = new Size(1243, 29);
            buttons[^1].TabIndex = 4;
            buttons[^1].Text = "Save";
            buttons[^1].UseVisualStyleBackColor = true;
            buttons[^1].Click += new EventHandler(buttons_Click);
            void text_KeyDown(object sender, EventArgs e)
            {
                changes += 1;
                changes %= int.Parse(toolStripComboBox1.SelectedItem.ToString());
                if (changes == 0)
                {
                    RichTextBox textBox = sender as RichTextBox;
                    int i = richTextBoxes.IndexOf(textBox);
                    try
                    {
                        if (tabPage[i].Text[^4..] == ".rtf")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                        }
                        else if (tabPage[i].Text[^4..] == ".txt")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                        }
                        else
                        {
                            File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                        }
                    }
                    catch (Exception ex)
                    {
                        label3.Text = ex.Message;
                    }
                }
            }
            void buttons_Click(object sender, EventArgs e)
            {
                Button button = sender as Button;
                int i = buttons.IndexOf(button);
                try
                {
                    File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                }
                catch (Exception ex)
                {
                    label3.Text = ex.Message;
                }
                tabPage.RemoveAt(i);
                richTextBoxes.RemoveAt(i);
                buttons.RemoveAt(i);
                tabControl1.TabPages.Remove(tabControl1.SelectedTab);

            }
        }

        /// <summary>
        /// Создание новой вкладки.
        /// </summary>
        private void button3_Click(object sender, EventArgs e)
        {
            NewButton();
            buttons[^1].Click += new EventHandler(buttons_Click);
            richTextBoxes[^1].TextChanged += text_KeyDown;
            void text_KeyDown(object sender, EventArgs e)
            {
                changes += 1;
                changes %= int.Parse(toolStripComboBox1.SelectedItem.ToString());
                if (changes == 0)
                {
                    RichTextBox textBox = sender as RichTextBox;
                    int i = richTextBoxes.IndexOf(textBox);
                    try
                    {
                        if (tabPage[i].Text[^4..] == ".rtf")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                        }
                        else if (tabPage[i].Text[^4..] == ".txt")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                        }
                        else
                        {
                            File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                        }
                    }
                    catch (Exception ex)
                    {
                        label3.Text = ex.Message;
                    }
                }
            }
            void buttons_Click(object sender, EventArgs e)
            {
                Button button = sender as Button;
                int i = buttons.IndexOf(button);
                try
                {
                    File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                }
                catch (Exception ex)
                {
                    label3.Text = ex.Message;
                }
                tabPage.RemoveAt(i);
                richTextBoxes.RemoveAt(i);
                buttons.RemoveAt(i);
                tabControl1.TabPages.Remove(tabControl1.SelectedTab);

            }
            CreationAndRecording();
        }

        /// <summary>
        /// Создание в новой вкладке кнопки сохранить и текст бокса.
        /// </summary>
        private void NewButton()
        {
            tabPage.Add(new TabPage());
            richTextBoxes.Add(new RichTextBox());
            buttons.Add(new Button());
            richTextBoxes[^1].Location = new Point(6, 3);
            richTextBoxes[^1].Name = $"richTextBox{richTextBoxes.Count}";
            richTextBoxes[^1].Size = new Size(1231, 329);
            richTextBoxes[^1].TabIndex = 7;
            richTextBoxes[^1].Text = "";
            richTextBoxes[^1].ContextMenuStrip = contextMenuStrip1;
            tabPage[^1].Controls.Add(richTextBoxes[^1]);
            buttons[^1].Location = new Point(0, 351);
            buttons[^1].Name = $"button{buttons.Count}";
            buttons[^1].Size = new Size(1243, 29);
            buttons[^1].TabIndex = 4;
            buttons[^1].Text = "Save";
            buttons[^1].UseVisualStyleBackColor = true;
        }

        /// <summary>
        /// Создаёт вкладку и записывает в ней текст из файла
        /// </summary>
        private void CreationAndRecording()
        {
            tabPage[^1].Controls.Add(buttons[^1]);
            tabPage[^1].Location = new Point(4, 29);
            tabPage[^1].Name = $"tabPage{tabPage.Count}";
            Padding = new Padding(3);
            tabPage[^1].Size = new Size(1243, 442);
            tabPage[^1].TabIndex = 0;
            tabPage[^1].Text = $"tabPage{tabPage.Count}";
            tabPage[^1].UseVisualStyleBackColor = true;
            tabControl1.Controls.Add(tabPage[^1]);
            try
            {
                richTextBoxes[^1].Rtf = File.ReadAllText(textBox1.Text);
                tabPage[^1].Text = textBox1.Text;
            }
            catch
            {
                try
                {
                    richTextBoxes[^1].Text = File.ReadAllText(textBox1.Text);
                    tabPage[^1].Text = textBox1.Text;
                }
                catch (Exception ex)
                {
                    label1.Text = ex.Message;
                }
            }
        }

        /// <summary>
        /// Сохранение настроек и меню выбора сохранения файлов.
        /// </summary>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            string[] settings = Setting();
            File.WriteAllLines("settings.txt", settings);
            if (tabPage.Count != 0)
            {
                DialogResult dialog = MessageBox.Show(
                 "Сохранить файлы?",
                 "Завершение программы",
                 MessageBoxButtons.YesNoCancel,
                 MessageBoxIcon.Warning
                );
                if (dialog == DialogResult.Yes)
                {
                    for (int i = 0; i < tabPage.Count; i++)
                    {
                        try
                        {
                            if (tabPage[i].Text[^4..] == ".rtf")
                            {
                                File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                            }
                            else
                            {
                                File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                            }
                        }
                        catch (Exception ex)
                        {
                            label3.Text = ex.Message;
                        }
                    }
                    e.Cancel = false;
                }
                else if (dialog == DialogResult.No)
                {
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }
            else
            {
                e.Cancel = false;
            }
        }

        /// <summary>
        /// Обработка настроек.
        /// </summary>
        /// <returns> строка настроек </returns>
        private string[] Setting()
        {
            string[] settings = new string[2 + tabPage.Count];
            settings[0] = BackColor.Name;
            settings[1] = toolStripComboBox1.SelectedIndex.ToString();
            for (int i = 2; i < settings.Length; i++)
            {
                settings[i] = tabPage[i - 2].Text;
            }

            return settings;
        }

        /// <summary>
        /// Сохранение текущего файла.
        /// </summary>
        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                try
                {
                    if (tabPage[i].Text[^4..] == ".rtf")
                    {
                        File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                    }
                    else
                    {
                        File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                    }
                }
                catch (Exception ex)
                {
                    label3.Text = ex.Message;
                }
                try
                {
                    tabPage.RemoveAt(i);
                    richTextBoxes.RemoveAt(i);
                    buttons.RemoveAt(i);
                    tabControl1.TabPages.Remove(tabControl1.SelectedTab);

                }
                catch
                {
                    Console.WriteLine("Файлов нет");
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Сохранение всех файлов
        /// </summary>
        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
            for (int i = tabPage.Count - 1; i >= 0; i--)
            {
                try
                {
                    if (tabPage[i].Text[^4..] == ".rtf")
                    {
                        File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                    }
                    else
                    {
                        File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                    }
                }
                catch (Exception ex)
                {
                    label3.Text = ex.Message;
                }
                tabControl1.TabPages.RemoveAt(i);
            }
            tabPage = new List<TabPage>();
            richTextBoxes = new List<RichTextBox>();
            buttons = new List<Button>();
        }

        /// <summary>
        /// Выделение всего текста в документе.
        /// </summary>
        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (!String.IsNullOrEmpty(richTextBoxes[i].Text))
                {
                    richTextBoxes[i].SelectionStart = 0;
                    richTextBoxes[i].SelectionLength = richTextBoxes[i].Text.Length;
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Создание документа в новой вкладке.
        /// </summary>
        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            CreationsButton();
            AutosaveAndClick();
            tabPage[^1].Controls.Add(buttons[^1]);
            tabPage[^1].Location = new Point(4, 29);
            tabPage[^1].Name = $"tabPage{tabPage.Count}";
            Padding = new Padding(3);
            tabPage[^1].Size = new Size(1243, 442);
            tabPage[^1].TabIndex = 0;
            tabPage[^1].Text = $"tabPage{tabPage.Count}";
            tabPage[^1].UseVisualStyleBackColor = true;
            tabControl1.Controls.Add(tabPage[^1]);

        }

        /// <summary>
        /// Подключение кнопки сохранения и автосохранения
        /// </summary>
        private void AutosaveAndClick()
        {
            richTextBoxes[^1].TextChanged += text_KeyDown;
            buttons[^1].Click += new EventHandler(buttons_Click);
            void text_KeyDown(object sender, EventArgs e)
            {
                changes += 1;
                changes %= int.Parse(toolStripComboBox1.SelectedItem.ToString());
                if (changes == 0)
                {
                    RichTextBox textBox = sender as RichTextBox;
                    int i = richTextBoxes.IndexOf(textBox);
                    try
                    {
                        if (tabPage[i].Text[^4..] == ".rtf")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                        }
                        else if (tabPage[i].Text[^4..] == ".txt")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                        }
                        else
                        {
                            File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                        }
                    }
                    catch (Exception ex)
                    {
                        label3.Text = ex.Message;
                    }
                }
            }
            void buttons_Click(object sender, EventArgs e)
            {
                Button button = sender as Button;
                int i = buttons.IndexOf(button);
                try
                {
                    File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                }
                catch (Exception ex)
                {
                    label3.Text = ex.Message;
                }
                tabPage.RemoveAt(i);
                richTextBoxes.RemoveAt(i);
                buttons.RemoveAt(i);
                tabControl1.TabPages.Remove(tabControl1.SelectedTab);

            }
        }

        /// <summary>
        /// Создание кнопки и текст бокса
        /// </summary>
        private void CreationsButton()
        {
            tabPage.Add(new TabPage());
            richTextBoxes.Add(new RichTextBox());
            buttons.Add(new Button());
            richTextBoxes[^1].Location = new Point(6, 3);
            richTextBoxes[^1].Name = $"richTextBox{richTextBoxes.Count}";
            richTextBoxes[^1].Size = new Size(1231, 329);
            richTextBoxes[^1].TabIndex = 7;
            richTextBoxes[^1].Text = "";
            richTextBoxes[^1].ContextMenuStrip = contextMenuStrip1;
            tabPage[^1].Controls.Add(richTextBoxes[^1]);
            buttons[^1].Location = new Point(0, 351);
            buttons[^1].Name = $"button{buttons.Count}";
            buttons[^1].Size = new Size(1243, 29);
            buttons[^1].TabIndex = 4;
            buttons[^1].Text = "Save";
            buttons[^1].UseVisualStyleBackColor = true;
        }

        /// <summary>
        /// Создание документа в новом окне.
        /// </summary>
        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            Form1 newForm = new Form1();
            newForm.Show();
            newForm.tabPage.Add(new TabPage());
            newForm.richTextBoxes.Add(new RichTextBox());
            newForm.buttons.Add(new Button());
            newForm.richTextBoxes[^1].Location = new Point(6, 3);
            newForm.richTextBoxes[^1].Name = $"richTextBox{richTextBoxes.Count}";
            newForm.richTextBoxes[^1].Size = new Size(1231, 329);
            newForm.richTextBoxes[^1].TabIndex = 7;
            newForm.richTextBoxes[^1].Text = "";
            newForm.richTextBoxes[^1].ContextMenuStrip = contextMenuStrip1;
            newForm.tabPage[^1].Controls.Add(newForm.richTextBoxes[^1]);
            newForm.buttons[^1].Location = new Point(0, 351);
            newForm.buttons[^1].Name = $"button{buttons.Count}";
            newForm.buttons[^1].Size = new Size(1243, 29);
            newForm.buttons[^1].TabIndex = 4;
            newForm.buttons[^1].Text = "Save";
            newForm.buttons[^1].UseVisualStyleBackColor = true;
            NewAutosaveAndClick(newForm);
            newForm.tabPage[^1].Controls.Add(newForm.buttons[^1]);
            newForm.tabPage[^1].Location = new Point(4, 29);
            newForm.tabPage[^1].Name = $"tabPage{newForm.tabPage.Count}";
            Padding = new Padding(3);
            newForm.tabPage[^1].Size = new Size(1243, 442);
            newForm.tabPage[^1].TabIndex = 0;
            newForm.tabPage[^1].Text = $"tabPage{newForm.tabPage.Count}";
            newForm.tabPage[^1].UseVisualStyleBackColor = true;
            newForm.tabControl1.Controls.Add(newForm.tabPage[^1]);
        }

        /// <summary>
        /// Подключение кнопки сохранения и автосохранения в новом окне.
        /// </summary>
        /// <param name="newForm"> Новая форма </param>
        private void NewAutosaveAndClick(Form1 newForm)
        {
            newForm.richTextBoxes[^1].TextChanged += text_KeyDown;
            newForm.buttons[^1].Click += new EventHandler(buttons_Click);
            void text_KeyDown(object sender, EventArgs e)
            {
                changes += 1;
                changes %= int.Parse(toolStripComboBox1.SelectedItem.ToString());
                if (changes == 0)
                {
                    RichTextBox textBox = sender as RichTextBox;
                    int i = richTextBoxes.IndexOf(textBox);
                    try
                    {
                        if (tabPage[i].Text[^4..] == ".rtf")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Rtf);
                        }
                        if (tabPage[i].Text[^4..] == ".txt")
                        {
                            File.WriteAllText(tabPage[i].Text, richTextBoxes[i].Text);
                        }
                        else
                        {
                            File.WriteAllText(tabPage[i].Text + ".txt", richTextBoxes[i].Text);
                        }
                    }
                    catch (Exception ex)
                    {
                        label3.Text = ex.Message;
                    }
                }
            }
            void buttons_Click(object sender, EventArgs e)
            {
                Button button = sender as Button;
                int i = newForm.buttons.IndexOf(button);
                try
                {
                    File.WriteAllText(newForm.tabPage[i].Text + ".txt", newForm.richTextBoxes[i].Text);
                }
                catch (Exception ex)
                {
                    newForm.label3.Text = ex.Message;
                }
                newForm.tabPage.RemoveAt(i);
                newForm.richTextBoxes.RemoveAt(i);
                newForm.buttons.RemoveAt(i);
                newForm.tabControl1.TabPages.Remove(newForm.tabControl1.SelectedTab);

            }
        }

        /// <summary>
        /// Копирование выделенного элемента.
        /// </summary>
        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (richTextBoxes[i].SelectionLength > 0)
                    richTextBoxes[i].Copy();
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Функция вставить.
        /// </summary>
        private void toolStripMenuItem12_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
                {
                    richTextBoxes[i].Paste();
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Изменение характеристики жирный текст.
        /// </summary>
        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Bold ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Изменение характеристики курсивный текст.
        /// </summary>
        private void toolStripMenuItem14_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Italic ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Изменение характеристики подчёркнутый текст
        /// </summary>
        private void toolStripMenuItem15_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Underline ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Изменение характеристики зачёркнутый текст.
        /// </summary>
        private void toolStripMenuItem16_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Strikeout ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Выделить весь текст(контекстное меню).
        /// </summary>
        private void toolStripMenuItem19_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (!String.IsNullOrEmpty(richTextBoxes[i].Text))
                {
                    richTextBoxes[i].SelectionStart = 0;
                    richTextBoxes[i].SelectionLength = richTextBoxes[i].Text.Length;
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Копирование с помощью контекстного меню
        /// </summary>
        private void toolStripMenuItem17_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (richTextBoxes[i].SelectionLength > 0)
                    richTextBoxes[i].Copy();
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Вставка с помощью контекстного меню
        /// </summary>
        private void toolStripMenuItem18_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (Clipboard.GetDataObject().GetDataPresent(DataFormats.Text) == true)
                {
                    richTextBoxes[i].Paste();
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Жирный текст(контекстное меню)
        /// </summary>
        private void toolStripMenuItem21_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Bold ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Курсив(контекстное меню)
        /// </summary>
        private void toolStripMenuItem22_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Italic ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Подчёркнуттый(контекстное меню)
        /// </summary>
        private void toolStripMenuItem23_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Underline ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Зачёркнутый(контекстное меню)
        /// </summary>
        private void toolStripMenuItem24_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                richTextBoxes[i].SelectionFont = new Font(richTextBoxes[i].SelectionFont, FontStyle.Strikeout ^ richTextBoxes[i].SelectionFont.Style);
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Вырезать текст(контекстное меню).
        /// </summary>
        private void toolStripMenuItem25_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (richTextBoxes[i].SelectionLength > 0)
                {
                    richTextBoxes[i].Cut();
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Функция вырезать.
        /// </summary>
        private void toolStripMenuItem26_Click(object sender, EventArgs e)
        {
            try
            {
                int i = tabPage.IndexOf(tabControl1.SelectedTab);
                if (richTextBoxes[i].SelectionLength > 0)
                {
                    richTextBoxes[i].Cut();
                }
            }
            catch
            {
                label1.Text = "нет открытых файлов";
            }
        }

        /// <summary>
        /// Изменение цвета фона на синий.
        /// </summary>
        private void toolStripMenuItem28_Click(object sender, EventArgs e)
        {
            BackColor = Color.Blue;
        }

        /// <summary>
        /// Изменение цвета фона на белый.
        /// </summary>
        private void toolStripMenuItem30_Click(object sender, EventArgs e)
        {
            BackColor = Color.White;
        }

        /// <summary>
        /// Изменение цвета фона на серый.
        /// </summary>
        private void toolStripMenuItem31_Click(object sender, EventArgs e)
        {
            BackColor = Color.Gray;
        }
    }
}
